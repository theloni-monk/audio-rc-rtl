cp hwbuild.py build.py
./remote/r.py build.py build.tcl dummy_model.sv hdl/* xdc/* data/* obj
