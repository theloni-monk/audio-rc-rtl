cp sbuild.py build.py
./remote/r.py build.py xsim_run.tcl hdl/* data/* dummy_model.sv sim/generated_integration_tb_0.sv obj